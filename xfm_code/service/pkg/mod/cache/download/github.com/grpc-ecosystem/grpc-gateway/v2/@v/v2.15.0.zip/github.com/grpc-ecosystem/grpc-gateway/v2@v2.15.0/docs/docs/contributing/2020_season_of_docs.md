---
layout: default
title: Google Season of Docs
nav_order: 1
parent: Contributing
---

# 2020 Season of Docs

<div align="center">
<img src="https://developers.google.com/season-of-docs/images/logo/SeasonofDocs_Logo_SecondaryGrey_300ppi.png" />
</div>

The gRPC-Gateway participated in the 2020 [Google Season of Docs](https://g.co/seasonofdocs).
The project was completed by [@iamrajiv](https://github.com/iamrajiv). A summary of the project
work can be found in the
[project report](https://github.com/iamrajiv/GSoD-2020/blob/master/GSoD_2020_Project_Report.md).
