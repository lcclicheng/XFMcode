package types

const VERSION = "2.4.0"
