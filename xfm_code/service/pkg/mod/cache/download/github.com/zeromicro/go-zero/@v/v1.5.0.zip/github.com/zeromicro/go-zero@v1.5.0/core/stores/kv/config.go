package kv

import "github.com/zeromicro/go-zero/core/stores/cache"

// KvConf is an alias of cache.ClusterConf.
type KvConf = cache.ClusterConf
