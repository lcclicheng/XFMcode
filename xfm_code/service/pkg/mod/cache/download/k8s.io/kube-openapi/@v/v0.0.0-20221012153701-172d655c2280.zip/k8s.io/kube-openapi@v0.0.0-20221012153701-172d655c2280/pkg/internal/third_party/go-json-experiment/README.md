Forked from: https://github.com/go-json-experiment/json
Commit Hash: 4987ed27d44794668c752d227a2d3a7be54570bc

This internal fork exists to prevent dependency issues with go-json-experiment
until its API stabilizes.