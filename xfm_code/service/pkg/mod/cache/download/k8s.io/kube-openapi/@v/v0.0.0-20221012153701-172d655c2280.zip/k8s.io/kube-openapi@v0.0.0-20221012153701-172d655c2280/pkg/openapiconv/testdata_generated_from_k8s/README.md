Please do not edit these test files by hand. They were generated from running the OpenAPI v2 and v3 builders on select Kubernetes groups.
